# KAPWA Resort OS

AI-powered resort management system built on LangGraph.

## Architecture

```
KAPWA Super Agent
├── Guest relations
├── Reservations
├── Front desk
├── Housekeeping
├── Maintenance
├── Staff coordination
├── Inventory
├── Purchasing
├── Finance analysis
└── Owner reporting
```

## Packages

| Package | Purpose |
|---------|---------|
| `resort-types` | Shared Pydantic models, enums, state definitions |
| `resort-data` | Mock resort data layer (JSON fixtures + in-memory store) |
| `resort-tools` | LangChain @tool definitions for resort operations |
| `agent-core` | LangGraph agent brain — graph, nodes, prompts, memory |
| `agent-api` | FastAPI server with SSE streaming |

## Quick Start

```bash
# Install dependencies
uv sync

# Run the agent (interactive)
uv run --package agent-core python -m agent_core.cli

# Start the API server
uv run --package agent-api uvicorn agent_api.main:app --reload
```

## LLM Configuration

Supports:
- **Ollama local** (qwen2.5:3b, hermes3) — free, no API key
- **OpenRouter** — free + cheap Chinese models (Qwen, DeepSeek)

Set environment variables:
```bash
OLLAMA_BASE_URL=http://localhost:11434
OPENROUTER_API_KEY=your-key-here
```

## Supabase / Lovable.dev

The `supabase/` directory contains migration SQL ready for Lovable.dev deployment.
When dropped into Lovable, connect Supabase and run migrations to set up the database.
