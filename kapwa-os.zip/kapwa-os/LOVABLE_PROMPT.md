# Lovable.dev Landing Page Prompt
# Copy everything below this line into Lovable's chat

---

Build a professional landing page and marketing site for "KAPWA Resort OS" — an AI-powered resort management platform for boutique resorts in Palawan Island, Philippines.

## Brand
- Name: KAPWA Resort OS
- Tagline: "Your Resort, Managed by AI"
- Color palette: Deep ocean teal (#0d9488), warm sand (#fbbf24), white, dark slate
- Font: Modern, clean (Inter or similar)
- Tone: Professional but warm, tropical, tech-forward

## Pages to build

### 1. Landing Page (Hero + Features)
- Hero section with large headline: "Run Your Resort with AI"
- Subheadline: "KAPWA is the intelligent operating system that coordinates your front desk, housekeeping, maintenance, reservations, inventory, and finances — all from one dashboard."
- CTA buttons: "See it in action" (scrolls to demo), "Get Started" (links to signup)
- Background: subtle tropical/ocean gradient or abstract wave pattern
- Features section with 6 cards:
  1. Guest Relations — AI handles guest requests, drafts replies, escalates issues
  2. Reservations — Smart booking management with availability checking
  3. Housekeeping & Maintenance — Auto-creates tasks, tracks completion
  4. Inventory Management — Low stock alerts, purchase proposals
  5. Financial Oversight — P&L tracking, expense proposals, audit logs
  6. Staff Coordination — Task assignment, shift management, department routing
- Each feature card: icon, title, 1-sentence description

### 2. How It Works (3 steps)
- Step 1: "Connect" — Link your resort data (rooms, guests, staff)
- Step 2: "Configure" — Set your AI model (Ollama local or OpenRouter cloud)
- Step 3: "Command" — Talk to KAPWA in natural language, it handles the rest

### 3. Demo Section
- Embedded mockup or illustration of the dashboard
- Show the agent chat interface with a sample conversation:
  User: "Guest in R102 says AC is broken"
  KAPWA: "I've classified this as a high-priority maintenance request. I've created task TK-0001 and drafted a reply to the guest. Awaiting your approval."

### 4. Pricing (simple)
- Free Tier: 1 resort, local AI (Ollama), basic features
- Pro: $49/mo, cloud AI (OpenRouter), up to 3 resorts, priority support
- Enterprise: Custom, unlimited resorts, dedicated support, API access

### 5. About / Trust
- "Built for island resorts" — Palawan-based team
- "Your data stays local" — Ollama option means no cloud dependency
- "Open foundation" — Built on LangGraph + Supabase

### 6. Footer
- Links: Product, Features, Pricing, Docs, GitHub, Contact
- "Made with ❤️ in Palawan Island, Philippines"
- Social icons placeholder

## Technical requirements
- Single-page app with smooth scroll navigation
- Fully responsive (mobile-first)
- Use Tailwind CSS for styling
- Use Lucide React for icons
- Supabase integration ready (auth + database)
- Admin dashboard at /admin with:
  - Agent chat interface (connects to backend API at /api/chat)
  - Resort state overview (connects to /api/state)
  - LLM Settings page (connects to /api/settings/llm):
    - Toggle between Ollama (local) and OpenRouter (cloud)
    - Model selector showing free/cheap/premium models
    - OpenRouter API key input
    - Ollama connection status indicator
    - Temperature slider
  - Guest list (connects to /api/guests)
  - Room status grid (connects to /api/rooms)
  - Pending approvals queue (connects to /api/approvals/pending)

## Environment variables
```
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
VITE_AGENT_API_URL=http://localhost:8001
```

## Important
- The backend API (FastAPI) runs separately on port 8001
- The dashboard connects to it via VITE_AGENT_API_URL
- Supabase is for user auth and persistent data
- The agent runs on LangGraph with LangChain tools
- Admin settings must support both Ollama (no API key needed, runs locally) and OpenRouter (needs API key, cloud-hosted models)
